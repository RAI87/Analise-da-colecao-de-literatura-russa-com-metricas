# Overview

This is a professional, advanced book recommendation system focused on Russian literature. The application implements multiple sophisticated machine learning algorithms including content-based filtering, collaborative filtering, sentiment analysis, and hybrid approaches. The system features a modern web interface, REST API, real-time analytics dashboard, and comprehensive data management with SQLite database.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Design Pattern
The application follows a professional modular architecture with separation of concerns:

- **Models Layer**: SQLite database with structured schemas for books, users, ratings, and recommendations
- **Services Layer**: Business logic including advanced ML algorithms and data processing
- **API Layer**: RESTful endpoints with comprehensive error handling and logging
- **Presentation Layer**: Modern responsive web interface with Bootstrap and Chart.js

## Advanced Recommendation Algorithms

### 1. Hybrid Algorithm (Recommended)
Combines multiple approaches with weighted scoring:
- Content-based filtering (60% weight)
- Collaborative filtering (40% weight)
- Fallback to sentiment analysis for cold-start problems

### 2. Content-Based Filtering
Uses advanced text processing:
- TF-IDF (Term Frequency-Inverse Document Frequency) vectorization
- Cosine similarity calculation for semantic matching
- Feature extraction from titles, authors, genres, themes, and descriptions

### 3. Sentiment Analysis
Leverages natural language processing:
- TextBlob for sentiment polarity and subjectivity analysis
- Emotional tone matching between books
- Theme sentiment correlation

### 4. Collaborative Filtering
Simulates user behavior patterns:
- Genre preference analysis
- Author affinity scoring
- Popularity-based recommendations with Bayesian averaging

## Database Architecture
- **SQLite**: Professional database with ACID compliance
- **Models**: Comprehensive data models with relationships
- **Schema**: Normalized tables for books, users, ratings, recommendations
- **Performance**: Indexed queries and connection pooling

## Web Architecture
- **Flask Framework**: Professional web framework with blueprints
- **REST API**: Comprehensive endpoints with JSON responses
- **Frontend**: Bootstrap 5 + Chart.js for modern, responsive UI
- **Analytics**: Real-time dashboard with interactive visualizations

## Code Organization
```
app/
├── models/          # Data models and database management
├── services/        # Business logic and ML algorithms
├── api/            # REST API endpoints and routing
├── templates/      # Jinja2 HTML templates
└── static/         # CSS, JavaScript, and assets
config/             # Application configuration
logs/               # Application logging
data/               # SQLite database storage
tests/              # Test suites (planned)
```

# External Dependencies

**Core Dependencies:**
- **Flask**: Professional web framework for API and web interface
- **TextBlob**: Natural language processing for sentiment analysis
- **NumPy**: Numerical computing for mathematical operations
- **Pandas**: Data manipulation and analysis
- **Plotly**: Interactive data visualizations
- **BeautifulSoup4**: Web scraping capabilities (future features)
- **Requests**: HTTP library for external API integrations

**Development Features:**
- Professional logging system with file and console output
- Error handling with comprehensive exception management
- Performance monitoring and caching capabilities
- Modular configuration system
- Extensible architecture for future ML model integration

**Production Ready:**
- Database migrations and schema management
- API documentation and versioning
- Security best practices implementation
- Scalable deployment configuration