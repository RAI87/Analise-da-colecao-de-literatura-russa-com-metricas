"""Configurações da aplicação"""
import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class DatabaseConfig:
    """Configurações do banco de dados"""
    url: str = "sqlite:///data/books.db"
    echo: bool = False
    pool_size: int = 10
    max_overflow: int = 20

@dataclass
class MLConfig:
    """Configurações de Machine Learning"""
    min_similarity_threshold: float = 0.1
    max_recommendations: int = 10
    use_advanced_algorithms: bool = True
    cache_embeddings: bool = True

@dataclass
class APIConfig:
    """Configurações da API"""
    host: str = "0.0.0.0"
    port: int = 5000
    debug: bool = True
    secret_key: str = "dev-secret-key-change-in-production"
    cors_origins: Optional[list] = None

@dataclass
class CacheConfig:
    """Configurações de cache"""
    enabled: bool = True
    redis_url: Optional[str] = None
    default_timeout: int = 300

@dataclass
class LoggingConfig:
    """Configurações de logging"""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: str = "logs/app.log"

class Settings:
    """Configurações centralizadas da aplicação"""
    
    def __init__(self):
        self.database = DatabaseConfig()
        self.ml = MLConfig()
        self.api = APIConfig()
        self.cache = CacheConfig()
        self.logging = LoggingConfig()
        
        # Configurações de produção via environment variables
        if os.getenv("PRODUCTION"):
            self.api.debug = False
            self.api.secret_key = os.getenv("SECRET_KEY", "prod-secret")
            self.database.url = os.getenv("DATABASE_URL", self.database.url)

# Instância global de configurações
settings = Settings()