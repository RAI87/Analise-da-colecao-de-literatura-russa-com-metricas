#!/usr/bin/env python3
"""
Sistema Avançado de Recomendação de Literatura Russa
==================================================

Sistema profissional de recomendação de livros usando algoritmos de Machine Learning,
interface web moderna e API REST completa.

Características:
- Múltiplos algoritmos de recomendação (Híbrido, Conteúdo, Sentimento, Colaborativo)
- Interface web responsiva com Bootstrap e JavaScript
- API REST documentada
- Analytics e visualizações em tempo real
- Banco de dados SQLite com ORM
- Sistema de cache e logging
- Análise de sentimento com TextBlob
- Algoritmos TF-IDF e similaridade de cosseno

Autor: Sistema IA Avançado
Data: 2025
"""

import os
import sys
import logging
from pathlib import Path

# Adicionar diretório raiz ao Python path
sys.path.insert(0, str(Path(__file__).parent))

from app.api.routes import create_app
from config.settings import settings

def setup_logging():
    """Configura sistema de logging profissional"""
    log_dir = Path('logs')
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=getattr(logging, settings.logging.level),
        format=settings.logging.format,
        handlers=[
            logging.FileHandler(settings.logging.file_path),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # Configurar logger específico da aplicação
    logger = logging.getLogger(__name__)
    logger.info("Sistema de recomendação iniciado")
    return logger

def main():
    """Função principal da aplicação"""
    try:
        # Setup logging
        logger = setup_logging()
        
        # Criar aplicação Flask
        app = create_app()
        
        logger.info(f"Iniciando servidor em {settings.api.host}:{settings.api.port}")
        logger.info(f"Modo debug: {settings.api.debug}")
        logger.info(f"Banco de dados: {settings.database.url}")
        
        # Mensagens de startup
        print("\n" + "="*70)
        print("🚀 SISTEMA AVANÇADO DE RECOMENDAÇÃO DE LITERATURA RUSSA")
        print("="*70)
        print(f"📱 Interface Web: http://{settings.api.host}:{settings.api.port}")
        print(f"🔗 API REST: http://{settings.api.host}:{settings.api.port}/api")
        print(f"📊 Dashboard: http://{settings.api.host}:{settings.api.port}")
        print(f"🎯 Recomendações: http://{settings.api.host}:{settings.api.port}/recommendations")
        print("="*70)
        print("🤖 Algoritmos Disponíveis:")
        print("   • Híbrido (Recomendado)")
        print("   • Baseado em Conteúdo (TF-IDF + Cosine Similarity)")
        print("   • Análise de Sentimento (TextBlob)")
        print("   • Filtro Colaborativo")
        print("="*70)
        print("📚 Features:")
        print("   • Machine Learning com scikit-learn")
        print("   • Processamento de Linguagem Natural")
        print("   • Analytics em tempo real")
        print("   • Interface responsiva")
        print("   • API REST documentada")
        print("   • Banco de dados SQLite")
        print("="*70)
        print("🎮 Para começar: Acesse o dashboard e explore as recomendações!")
        print("="*70 + "\n")
        
        # Executar servidor
        app.run(
            host=settings.api.host,
            port=settings.api.port,
            debug=settings.api.debug,
            threaded=True
        )
        
    except Exception as e:
        print(f"❌ Erro ao iniciar aplicação: {e}")
        logger.error(f"Erro crítico: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()