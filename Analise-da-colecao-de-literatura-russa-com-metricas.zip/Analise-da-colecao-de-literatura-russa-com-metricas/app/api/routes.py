"""Rotas da API REST"""
from flask import Flask, request, jsonify, render_template
from typing import Dict, Any, List
import logging
from app.models.database import DatabaseManager
from app.models.book import Book
from app.services.recommendation_engine import AdvancedRecommendationEngine
from app.services.data_service import DataService
from config.settings import settings

# Configurar logging
logging.basicConfig(
    level=getattr(logging, settings.logging.level),
    format=settings.logging.format
)
logger = logging.getLogger(__name__)

def create_app() -> Flask:
    """Cria e configura a aplicação Flask"""
    app = Flask(__name__, 
                template_folder='../templates',
                static_folder='../static')
    
    app.config['SECRET_KEY'] = settings.api.secret_key
    app.config['DEBUG'] = settings.api.debug
    
    # Inicializar serviços
    db_manager = DatabaseManager()
    recommendation_engine = AdvancedRecommendationEngine(db_manager)
    data_service = DataService(db_manager)
    
    # Rota principal - Dashboard
    @app.route('/')
    def dashboard():
        """Dashboard principal com estatísticas"""
        try:
            books = db_manager.get_all_books()
            stats = data_service.get_analytics_data()
            return render_template('dashboard.html', books=books, stats=stats)
        except Exception as e:
            logger.error(f"Erro no dashboard: {e}")
            return render_template('error.html', message="Erro ao carregar dashboard"), 500
    
    # Rota de recomendações - Interface web
    @app.route('/recommendations')
    def recommendations_page():
        """Página de recomendações"""
        books = db_manager.get_all_books()
        return render_template('recommendations.html', books=books)
    
    # API REST Endpoints
    
    @app.route('/api/books', methods=['GET'])
    def get_books():
        """Lista todos os livros"""
        try:
            books = db_manager.get_all_books()
            return jsonify([book.to_dict() for book in books])
        except Exception as e:
            logger.error(f"Erro ao buscar livros: {e}")
            return jsonify({'error': 'Erro interno do servidor'}), 500
    
    @app.route('/api/books/<int:book_id>', methods=['GET'])
    def get_book(book_id: int):
        """Obtém um livro específico"""
        try:
            book = db_manager.get_book_by_id(book_id)
            if book:
                return jsonify(book.to_dict())
            return jsonify({'error': 'Livro não encontrado'}), 404
        except Exception as e:
            logger.error(f"Erro ao buscar livro {book_id}: {e}")
            return jsonify({'error': 'Erro interno do servidor'}), 500
    
    @app.route('/api/books/search', methods=['GET'])
    def search_books():
        """Busca livros por título"""
        query = request.args.get('q', '')
        if not query:
            return jsonify({'error': 'Parâmetro de busca obrigatório'}), 400
        
        try:
            book = db_manager.find_book_by_title(query)
            if book:
                return jsonify(book.to_dict())
            return jsonify({'error': 'Livro não encontrado'}), 404
        except Exception as e:
            logger.error(f"Erro na busca: {e}")
            return jsonify({'error': 'Erro interno do servidor'}), 500
    
    @app.route('/api/recommendations', methods=['POST'])
    def get_recommendations():
        """Obtém recomendações para um livro"""
        data = request.get_json()
        if not data or 'book_title' not in data:
            return jsonify({'error': 'Título do livro obrigatório'}), 400
        
        try:
            book_title = data['book_title']
            algorithm = data.get('algorithm', 'hybrid')
            user_id = data.get('user_id')
            
            # Encontrar o livro
            target_book = db_manager.find_book_by_title(book_title)
            if not target_book:
                return jsonify({'error': 'Livro não encontrado'}), 404
            
            # Obter todos os livros
            all_books = db_manager.get_all_books()
            
            # Gerar recomendações baseadas no algoritmo
            if algorithm == 'content':
                recommendations = recommendation_engine.content_based_similarity(target_book, all_books)
                recs_data = [{
                    'book': book.to_dict(),
                    'score': score,
                    'algorithm': 'content-based'
                } for book, score in recommendations]
                
            elif algorithm == 'collaborative':
                if not user_id:
                    return jsonify({'error': 'User ID obrigatório para filtro colaborativo'}), 400
                recommendations = recommendation_engine.collaborative_filtering(user_id, all_books)
                recs_data = [{
                    'book': book.to_dict(),
                    'score': score,
                    'algorithm': 'collaborative'
                } for book, score in recommendations]
                
            elif algorithm == 'sentiment':
                recommendations = recommendation_engine.sentiment_analysis_recommendations(target_book, all_books)
                recs_data = [{
                    'book': book.to_dict(),
                    'score': score,
                    'algorithm': 'sentiment-analysis'
                } for book, score in recommendations]
                
            else:  # hybrid (padrão)
                recommendations = recommendation_engine.hybrid_recommendations(target_book, user_id, all_books)
                recs_data = [{
                    'book': book.to_dict(),
                    'score': score,
                    'algorithm': algorithm_used
                } for book, score, algorithm_used in recommendations]
            
            return jsonify({
                'target_book': target_book.to_dict(),
                'recommendations': recs_data,
                'algorithm_used': algorithm
            })
            
        except Exception as e:
            logger.error(f"Erro ao gerar recomendações: {e}")
            return jsonify({'error': 'Erro interno do servidor'}), 500
    
    @app.route('/api/analytics', methods=['GET'])
    def get_analytics():
        """Obtém dados de analytics"""
        try:
            analytics = data_service.get_analytics_data()
            return jsonify(analytics)
        except Exception as e:
            logger.error(f"Erro ao obter analytics: {e}")
            return jsonify({'error': 'Erro interno do servidor'}), 500
    
    @app.route('/api/similarity/<int:book_id>', methods=['GET'])
    def get_similarity_analysis(book_id: int):
        """Análise detalhada de similaridade"""
        try:
            target_book = db_manager.get_book_by_id(book_id)
            if not target_book:
                return jsonify({'error': 'Livro não encontrado'}), 404
            
            all_books = db_manager.get_all_books()
            
            # Múltiplos algoritmos para comparação
            content_recs = recommendation_engine.content_based_similarity(target_book, all_books)
            sentiment_recs = recommendation_engine.sentiment_analysis_recommendations(target_book, all_books)
            
            return jsonify({
                'book': target_book.to_dict(),
                'content_based': [{'book': book.to_dict(), 'score': score} for book, score in content_recs[:5]],
                'sentiment_based': [{'book': book.to_dict(), 'score': score} for book, score in sentiment_recs[:5]]
            })
            
        except Exception as e:
            logger.error(f"Erro na análise de similaridade: {e}")
            return jsonify({'error': 'Erro interno do servidor'}), 500
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Endpoint não encontrado'}), 404
        return render_template('error.html', message="Página não encontrada"), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Erro interno do servidor'}), 500
        return render_template('error.html', message="Erro interno do servidor"), 500
    
    return app