"""Configuração e manipulação do banco de dados"""
import sqlite3
import json
from typing import List, Optional, Dict, Any
from contextlib import contextmanager
from pathlib import Path
from app.models.book import Book, User, Rating, Recommendation

class DatabaseManager:
    """Gerenciador do banco de dados SQLite"""
    
    def __init__(self, db_path: str = "data/books.db"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.init_database()
    
    @contextmanager
    def get_connection(self):
        """Context manager para conexões do banco"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
    
    def init_database(self):
        """Inicializa as tabelas do banco de dados"""
        with self.get_connection() as conn:
            # Tabela de livros
            conn.execute('''
                CREATE TABLE IF NOT EXISTS books (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    titulo TEXT NOT NULL,
                    autor TEXT NOT NULL,
                    genero TEXT NOT NULL,
                    temas TEXT NOT NULL,  -- JSON array
                    ano_publicacao INTEGER,
                    descricao TEXT,
                    isbn TEXT,
                    paginas INTEGER,
                    idioma TEXT DEFAULT 'português',
                    editora TEXT,
                    avaliacao_media REAL DEFAULT 0.0,
                    numero_avaliacoes INTEGER DEFAULT 0,
                    embeddings TEXT,  -- JSON object
                    metadata TEXT,    -- JSON object
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            ''')
            
            # Tabela de usuários
            conn.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    preferences TEXT,  -- JSON object
                    reading_history TEXT,  -- JSON array
                    favorite_authors TEXT,  -- JSON array
                    favorite_genres TEXT,   -- JSON array
                    created_at TEXT NOT NULL,
                    last_login TEXT,
                    is_active BOOLEAN DEFAULT 1
                )
            ''')
            
            # Tabela de avaliações
            conn.execute('''
                CREATE TABLE IF NOT EXISTS ratings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    book_id INTEGER NOT NULL,
                    rating REAL NOT NULL,
                    review TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (id),
                    FOREIGN KEY (book_id) REFERENCES books (id),
                    UNIQUE(user_id, book_id)
                )
            ''')
            
            # Tabela de recomendações
            conn.execute('''
                CREATE TABLE IF NOT EXISTS recommendations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    book_id INTEGER NOT NULL,
                    score REAL NOT NULL,
                    algorithm_used TEXT NOT NULL,
                    explanation TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (id),
                    FOREIGN KEY (book_id) REFERENCES books (id)
                )
            ''')
            
            conn.commit()
    
    def insert_book(self, book: Book) -> Optional[int]:
        """Insere um novo livro no banco"""
        with self.get_connection() as conn:
            cursor = conn.execute('''
                INSERT INTO books (titulo, autor, genero, temas, ano_publicacao, 
                                 descricao, isbn, paginas, idioma, editora,
                                 avaliacao_media, numero_avaliacoes, embeddings, 
                                 metadata, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                book.titulo, book.autor, book.genero, json.dumps(book.temas),
                book.ano_publicacao, book.descricao, book.isbn, book.paginas,
                book.idioma, book.editora, book.avaliacao_media, book.numero_avaliacoes,
                json.dumps(book.embeddings) if book.embeddings else None,
                json.dumps(book.metadata), book.created_at.isoformat(),
                book.updated_at.isoformat()
            ))
            conn.commit()
            return cursor.lastrowid
    
    def get_all_books(self) -> List[Book]:
        """Retorna todos os livros do banco"""
        with self.get_connection() as conn:
            rows = conn.execute('SELECT * FROM books ORDER BY titulo').fetchall()
            books = []
            for row in rows:
                book_data = dict(row)
                book_data['temas'] = json.loads(book_data['temas'])
                if book_data['embeddings']:
                    book_data['embeddings'] = json.loads(book_data['embeddings'])
                if book_data['metadata']:
                    book_data['metadata'] = json.loads(book_data['metadata'])
                else:
                    book_data['metadata'] = {}
                books.append(Book.from_dict(book_data))
            return books
    
    def get_book_by_id(self, book_id: int) -> Optional[Book]:
        """Retorna um livro pelo ID"""
        with self.get_connection() as conn:
            row = conn.execute('SELECT * FROM books WHERE id = ?', (book_id,)).fetchone()
            if row:
                book_data = dict(row)
                book_data['temas'] = json.loads(book_data['temas'])
                if book_data['embeddings']:
                    book_data['embeddings'] = json.loads(book_data['embeddings'])
                if book_data['metadata']:
                    book_data['metadata'] = json.loads(book_data['metadata'])
                else:
                    book_data['metadata'] = {}
                return Book.from_dict(book_data)
        return None
    
    def find_book_by_title(self, title: str) -> Optional[Book]:
        """Encontra um livro pelo título (busca flexível)"""
        with self.get_connection() as conn:
            row = conn.execute(
                'SELECT * FROM books WHERE LOWER(titulo) LIKE ?', 
                (f'%{title.lower()}%',)
            ).fetchone()
            if row:
                book_data = dict(row)
                book_data['temas'] = json.loads(book_data['temas'])
                if book_data['embeddings']:
                    book_data['embeddings'] = json.loads(book_data['embeddings'])
                if book_data['metadata']:
                    book_data['metadata'] = json.loads(book_data['metadata'])
                else:
                    book_data['metadata'] = {}
                return Book.from_dict(book_data)
        return None