"""Modelo de dados para livros"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime
import json

@dataclass
class Book:
    """Classe principal para representar um livro"""
    id: Optional[int] = None
    titulo: str = ""
    autor: str = ""
    genero: str = ""
    temas: List[str] = field(default_factory=list)
    ano_publicacao: Optional[int] = None
    descricao: Optional[str] = None
    isbn: Optional[str] = None
    paginas: Optional[int] = None
    idioma: str = "português"
    editora: Optional[str] = None
    avaliacao_media: float = 0.0
    numero_avaliacoes: int = 0
    embeddings: Optional[Dict[str, List[float]]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o livro para dicionário"""
        return {
            'id': self.id,
            'titulo': self.titulo,
            'autor': self.autor,
            'genero': self.genero,
            'temas': self.temas,
            'ano_publicacao': self.ano_publicacao,
            'descricao': self.descricao,
            'isbn': self.isbn,
            'paginas': self.paginas,
            'idioma': self.idioma,
            'editora': self.editora,
            'avaliacao_media': self.avaliacao_media,
            'numero_avaliacoes': self.numero_avaliacoes,
            'embeddings': self.embeddings,
            'metadata': self.metadata,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Book':
        """Cria um livro a partir de dicionário"""
        if 'created_at' in data and isinstance(data['created_at'], str):
            data['created_at'] = datetime.fromisoformat(data['created_at'])
        if 'updated_at' in data and isinstance(data['updated_at'], str):
            data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)
    
    def get_text_for_similarity(self) -> str:
        """Retorna texto combinado para análise de similaridade"""
        text_parts = [
            self.titulo,
            self.autor,
            self.genero,
            ' '.join(self.temas),
            self.descricao or ""
        ]
        return ' '.join(filter(None, text_parts))

@dataclass
class User:
    """Modelo de usuário do sistema"""
    id: Optional[int] = None
    username: str = ""
    email: str = ""
    password_hash: str = ""
    preferences: Dict[str, Any] = field(default_factory=dict)
    reading_history: List[int] = field(default_factory=list)  # IDs dos livros lidos
    favorite_authors: List[str] = field(default_factory=list)
    favorite_genres: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    last_login: Optional[datetime] = None
    is_active: bool = True

@dataclass
class Recommendation:
    """Modelo para representar uma recomendação"""
    user_id: int = 0
    book_id: int = 0
    score: float = 0.0
    algorithm_used: str = ""
    explanation: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    
@dataclass
class Rating:
    """Modelo para avaliações de livros"""
    id: Optional[int] = None
    user_id: int = 0
    book_id: int = 0
    rating: float = 0.0  # 1.0 a 5.0
    review: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)