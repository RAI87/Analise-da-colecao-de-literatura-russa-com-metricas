"""Motor de recomendações avançado com múltiplos algoritmos"""
import math
from typing import List, Dict, Tuple, Optional
from collections import Counter
from textblob import TextBlob
from app.models.book import Book, User, Recommendation
from app.models.database import DatabaseManager
from config.settings import settings

class AdvancedRecommendationEngine:
    """Motor de recomendações com múltiplos algoritmos"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self._tf_idf_cache = {}
        self._books_cache = None
        
    def _calculate_tf_idf(self, text: str, all_texts: List[str]) -> Dict[str, float]:
        """Calcula TF-IDF simplificado para um texto"""
        words = text.lower().split()
        word_count = len(words)
        tf = Counter(words)
        
        # Term Frequency
        for word in tf:
            tf[word] = tf[word] / word_count
        
        # Document Frequency
        doc_count = len(all_texts)
        idf = {}
        for word in tf:
            containing_docs = sum(1 for doc in all_texts if word in doc.lower())
            idf[word] = math.log(doc_count / containing_docs) if containing_docs > 0 else 0
        
        # TF-IDF
        tf_idf = {}
        for word in tf:
            tf_idf[word] = tf[word] * idf[word]
        
        return tf_idf
    
    def content_based_similarity(self, target_book: Book, books: List[Book]) -> List[Tuple[Book, float]]:
        """Algoritmo baseado em conteúdo usando TF-IDF e similaridade de cosseno simplificados"""
        all_texts = [book.get_text_for_similarity() for book in books]
        target_text = target_book.get_text_for_similarity()
        
        # Calcular TF-IDF para o livro alvo
        target_tfidf = self._calculate_tf_idf(target_text, all_texts)
        
        recommendations = []
        for book in books:
            if book.id == target_book.id:
                continue
                
            book_text = book.get_text_for_similarity()
            book_tfidf = self._calculate_tf_idf(book_text, all_texts)
            
            # Similaridade de cosseno simplificada
            similarity = self._cosine_similarity(target_tfidf, book_tfidf)
            
            if similarity > settings.ml.min_similarity_threshold:
                recommendations.append((book, similarity))
        
        recommendations.sort(key=lambda x: x[1], reverse=True)
        return recommendations[:settings.ml.max_recommendations]
    
    def _cosine_similarity(self, vec1: Dict[str, float], vec2: Dict[str, float]) -> float:
        """Calcula similaridade de cosseno entre dois vetores TF-IDF"""
        # Encontrar palavras comuns
        common_words = set(vec1.keys()) & set(vec2.keys())
        
        if not common_words:
            return 0.0
        
        # Produto escalar
        dot_product = sum(vec1[word] * vec2[word] for word in common_words)
        
        # Magnitudes
        magnitude1 = math.sqrt(sum(val**2 for val in vec1.values()))
        magnitude2 = math.sqrt(sum(val**2 for val in vec2.values()))
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    def collaborative_filtering(self, user_id: int, books: List[Book]) -> List[Tuple[Book, float]]:
        """Filtro colaborativo baseado em avaliações de usuários"""
        # Simular matriz usuário-item (em um sistema real seria do banco)
        # Por enquanto, usar dados sintéticos baseados em gêneros e autores
        recommendations = []
        
        # Algoritmo simplificado que considera preferências por gênero e autor
        user_history = self._get_user_reading_history(user_id)
        if not user_history:
            return self.popularity_based_recommendations(books)
        
        # Análise de preferências do usuário
        preferred_genres = self._extract_preferred_genres(user_history)
        preferred_authors = self._extract_preferred_authors(user_history)
        
        for book in books:
            if book.id not in [b.id for b in user_history]:
                score = 0.0
                
                # Peso por gênero preferido
                if book.genero in preferred_genres:
                    score += 0.4 * preferred_genres[book.genero]
                
                # Peso por autor preferido
                if book.autor in preferred_authors:
                    score += 0.3 * preferred_authors[book.autor]
                
                # Peso por avaliação média
                score += 0.2 * (book.avaliacao_media / 5.0)
                
                # Peso por popularidade (número de avaliações)
                popularity_score = min(book.numero_avaliacoes / 100.0, 1.0)
                score += 0.1 * popularity_score
                
                if score > settings.ml.min_similarity_threshold:
                    recommendations.append((book, score))
        
        recommendations.sort(key=lambda x: x[1], reverse=True)
        return recommendations[:settings.ml.max_recommendations]
    
    def hybrid_recommendations(self, target_book: Book, user_id: Optional[int], books: List[Book]) -> List[Tuple[Book, float, str]]:
        """Algoritmo híbrido combinando múltiplas abordagens"""
        content_recs = self.content_based_similarity(target_book, books)
        
        if user_id:
            collab_recs = self.collaborative_filtering(user_id, books)
            
            # Combinar recomendações com pesos
            combined_scores = {}
            
            # Peso 60% para conteúdo
            for book, score in content_recs:
                combined_scores[book.id] = {
                    'book': book,
                    'score': 0.6 * score,
                    'method': 'content+collaborative'
                }
            
            # Peso 40% para colaborativo
            for book, score in collab_recs:
                if book.id in combined_scores:
                    combined_scores[book.id]['score'] += 0.4 * score
                else:
                    combined_scores[book.id] = {
                        'book': book,
                        'score': 0.4 * score,
                        'method': 'collaborative'
                    }
            
            # Converter para lista e ordenar
            recommendations = [(
                data['book'], 
                data['score'], 
                data['method']
            ) for data in combined_scores.values()]
            
        else:
            # Apenas baseado em conteúdo
            recommendations = [(book, score, 'content-based') for book, score in content_recs]
        
        recommendations.sort(key=lambda x: x[1], reverse=True)
        return recommendations[:settings.ml.max_recommendations]
    
    def popularity_based_recommendations(self, books: List[Book]) -> List[Tuple[Book, float]]:
        """Recomendações baseadas em popularidade"""
        # Ordenar por avaliação média ponderada pelo número de avaliações
        recommendations = []
        for book in books:
            # Fórmula de Bayesian Average para ranking
            avg_rating = book.avaliacao_media
            num_ratings = book.numero_avaliacoes
            global_avg = 3.5  # Média global assumida
            min_ratings = 5   # Mínimo de avaliações para confiabilidade
            
            bayesian_avg = ((min_ratings * global_avg) + (num_ratings * avg_rating)) / (min_ratings + num_ratings)
            recommendations.append((book, bayesian_avg / 5.0))  # Normalizar para 0-1
        
        recommendations.sort(key=lambda x: x[1], reverse=True)
        return recommendations[:settings.ml.max_recommendations]
    
    def sentiment_analysis_recommendations(self, target_book: Book, books: List[Book]) -> List[Tuple[Book, float]]:
        """Recomendações baseadas em análise de sentimento dos temas"""
        target_sentiment = self._analyze_book_sentiment(target_book)
        recommendations = []
        
        for book in books:
            if book.id != target_book.id:
                book_sentiment = self._analyze_book_sentiment(book)
                similarity = self._sentiment_similarity(target_sentiment, book_sentiment)
                if similarity > settings.ml.min_similarity_threshold:
                    recommendations.append((book, similarity))
        
        recommendations.sort(key=lambda x: x[1], reverse=True)
        return recommendations[:settings.ml.max_recommendations]
    
    def _analyze_book_sentiment(self, book: Book) -> Dict[str, float]:
        """Analisa o sentimento dos temas e descrição do livro"""
        text = f"{' '.join(book.temas)} {book.descricao or ''}"
        blob = TextBlob(text)
        
        return {
            'polarity': blob.sentiment.polarity,  # -1 (negativo) a 1 (positivo)
            'subjectivity': blob.sentiment.subjectivity  # 0 (objetivo) a 1 (subjetivo)
        }
    
    def _sentiment_similarity(self, sent1: Dict[str, float], sent2: Dict[str, float]) -> float:
        """Calcula similaridade entre sentimentos"""
        polarity_diff = abs(sent1['polarity'] - sent2['polarity'])
        subjectivity_diff = abs(sent1['subjectivity'] - sent2['subjectivity'])
        
        # Converter diferenças em similaridade (0-1)
        polarity_sim = 1 - (polarity_diff / 2)  # /2 porque máxima diferença é 2
        subjectivity_sim = 1 - subjectivity_diff
        
        return (polarity_sim + subjectivity_sim) / 2
    
    def _get_user_reading_history(self, user_id: int) -> List[Book]:
        """Obtém histórico de leitura do usuário"""
        # Em um sistema real, seria uma consulta ao banco
        # Por enquanto, retorna lista vazia
        return []
    
    def _extract_preferred_genres(self, books: List[Book]) -> Dict[str, float]:
        """Extrai gêneros preferidos do histórico"""
        genre_count = {}
        for book in books:
            genre_count[book.genero] = genre_count.get(book.genero, 0) + 1
        
        total = len(books)
        return {genre: count/total for genre, count in genre_count.items()}
    
    def _extract_preferred_authors(self, books: List[Book]) -> Dict[str, float]:
        """Extrai autores preferidos do histórico"""
        author_count = {}
        for book in books:
            author_count[book.autor] = author_count.get(book.autor, 0) + 1
        
        total = len(books)
        return {author: count/total for author, count in author_count.items()}