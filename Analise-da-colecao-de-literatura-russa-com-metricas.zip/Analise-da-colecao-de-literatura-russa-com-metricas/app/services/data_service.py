"""Serviço para manipulação de dados e analytics"""
from typing import Dict, List, Any
import json
from datetime import datetime
from app.models.database import DatabaseManager
from app.models.book import Book

class DataService:
    """Serviço para operações de dados e analytics"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.initialize_sample_data()
    
    def initialize_sample_data(self):
        """Inicializa dados de exemplo no banco"""
        # Verificar se já há dados
        existing_books = self.db.get_all_books()
        if existing_books:
            return
        
        # Dados expandidos de literatura russa
        sample_books = [
            {
                'titulo': 'Crime e Castigo',
                'autor': 'Fiódor Dostoiévski',
                'genero': 'psicológico',
                'temas': ['crime', 'culpa', 'redenção', 'psicologia', 'moral'],
                'ano_publicacao': 1866,
                'descricao': 'Romance psicológico sobre Raskolnikov, um estudante que comete um assassinato e lida com as consequências morais e psicológicas.',
                'paginas': 592,
                'editora': 'Editora 34',
                'avaliacao_media': 4.5,
                'numero_avaliacoes': 1250
            },
            {
                'titulo': 'Guerra e Paz',
                'autor': 'Lev Tolstói',
                'genero': 'épico',
                'temas': ['guerra', 'amor', 'história', 'sociedade', 'destino'],
                'ano_publicacao': 1869,
                'descricao': 'Épico histórico sobre a sociedade russa durante as guerras napoleônicas, seguindo várias famílias aristocráticas.',
                'paginas': 1408,
                'editora': 'Cosac Naify',
                'avaliacao_media': 4.7,
                'numero_avaliacoes': 980
            },
            {
                'titulo': 'Anna Kariênina',
                'autor': 'Lev Tolstói',
                'genero': 'romance',
                'temas': ['amor', 'traição', 'sociedade', 'família', 'paixão'],
                'ano_publicacao': 1877,
                'descricao': 'Romance sobre Anna Kariênina e seu relacionamento extraconjugal que escandaliza a sociedade russa.',
                'paginas': 864,
                'editora': 'Companhia das Letras',
                'avaliacao_media': 4.4,
                'numero_avaliacoes': 760
            },
            {
                'titulo': 'Os Irmãos Karamázov',
                'autor': 'Fiódor Dostoiévski',
                'genero': 'filosófico',
                'temas': ['fé', 'liberdade', 'moral', 'família', 'justiça'],
                'ano_publicacao': 1880,
                'descricao': 'Último romance de Dostoiévski, explorando questões de fé, moral e a natureza humana através da família Karamázov.',
                'paginas': 952,
                'editora': 'Editora 34',
                'avaliacao_media': 4.6,
                'numero_avaliacoes': 540
            },
            {
                'titulo': 'O Idiota',
                'autor': 'Fiódor Dostoiévski',
                'genero': 'psicológico',
                'temas': ['inocência', 'sociedade', 'bondade', 'epilepsia', 'moralidade'],
                'ano_publicacao': 1869,
                'descricao': 'História do príncipe Myshkin, um homem puro e inocente navegando pela sociedade corrupta de São Petersburgo.',
                'paginas': 720,
                'editora': 'Editora 34',
                'avaliacao_media': 4.3,
                'numero_avaliacoes': 420
            },
            {
                'titulo': 'Pais e Filhos',
                'autor': 'Ivan Turguêniev',
                'genero': 'social',
                'temas': ['conflito geracional', 'nihilismo', 'amor', 'ideologia', 'modernidade'],
                'ano_publicacao': 1862,
                'descricao': 'Romance sobre o conflito entre gerações e ideologias na Rússia do século XIX.',
                'paginas': 320,
                'editora': 'Penguin Classics',
                'avaliacao_media': 4.2,
                'numero_avaliacoes': 310
            },
            {
                'titulo': 'Doutor Jivago',
                'autor': 'Boris Pasternak',
                'genero': 'histórico',
                'temas': ['revolução', 'amor', 'guerra civil', 'destino', 'arte'],
                'ano_publicacao': 1957,
                'descricao': 'Romance sobre um médico-poeta durante a Revolução Russa e seus conflitos pessoais e políticos.',
                'paginas': 592,
                'editora': 'Companhia das Letras',
                'avaliacao_media': 4.1,
                'numero_avaliacoes': 280
            },
            {
                'titulo': 'O Mestre e Margarida',
                'autor': 'Mikhail Bulgákov',
                'genero': 'fantástico',
                'temas': ['satanismo', 'censura', 'amor', 'arte', 'crítica social'],
                'ano_publicacao': 1967,
                'descricao': 'Romance satírico sobre a visita do diabo à Moscou soviética, misturando fantasia, romance e crítica social.',
                'paginas': 480,
                'editora': 'Editora 34',
                'avaliacao_media': 4.5,
                'numero_avaliacoes': 650
            }
        ]
        
        # Inserir livros no banco
        for book_data in sample_books:
            book = Book(
                titulo=book_data['titulo'],
                autor=book_data['autor'],
                genero=book_data['genero'],
                temas=book_data['temas'],
                ano_publicacao=book_data['ano_publicacao'],
                descricao=book_data['descricao'],
                paginas=book_data['paginas'],
                editora=book_data['editora'],
                avaliacao_media=book_data['avaliacao_media'],
                numero_avaliacoes=book_data['numero_avaliacoes'],
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            self.db.insert_book(book)
    
    def get_analytics_data(self) -> Dict[str, Any]:
        """Gera dados de analytics do sistema"""
        books = self.db.get_all_books()
        
        # Estatísticas básicas
        total_books = len(books)
        total_pages = sum(book.paginas or 0 for book in books)
        avg_rating = sum(book.avaliacao_media for book in books) / total_books if total_books > 0 else 0
        total_reviews = sum(book.numero_avaliacoes for book in books)
        
        # Análise por gênero
        genre_stats = {}
        for book in books:
            genre = book.genero
            if genre not in genre_stats:
                genre_stats[genre] = {
                    'count': 0,
                    'avg_rating': 0,
                    'total_pages': 0,
                    'books': []
                }
            genre_stats[genre]['count'] += 1
            genre_stats[genre]['avg_rating'] += book.avaliacao_media
            genre_stats[genre]['total_pages'] += book.paginas or 0
            genre_stats[genre]['books'].append(book.titulo)
        
        # Calcular médias
        for genre in genre_stats:
            if genre_stats[genre]['count'] > 0:
                genre_stats[genre]['avg_rating'] /= genre_stats[genre]['count']
        
        # Análise por autor
        author_stats = {}
        for book in books:
            author = book.autor
            if author not in author_stats:
                author_stats[author] = {
                    'count': 0,
                    'avg_rating': 0,
                    'books': []
                }
            author_stats[author]['count'] += 1
            author_stats[author]['avg_rating'] += book.avaliacao_media
            author_stats[author]['books'].append(book.titulo)
        
        # Calcular médias dos autores
        for author in author_stats:
            if author_stats[author]['count'] > 0:
                author_stats[author]['avg_rating'] /= author_stats[author]['count']
        
        # Top temas
        theme_count = {}
        for book in books:
            for theme in book.temas:
                theme_count[theme] = theme_count.get(theme, 0) + 1
        
        top_themes = sorted(theme_count.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Análise temporal
        year_stats = {}
        for book in books:
            if book.ano_publicacao:
                century = (book.ano_publicacao // 100) + 1
                if century not in year_stats:
                    year_stats[century] = 0
                year_stats[century] += 1
        
        return {
            'overview': {
                'total_books': total_books,
                'total_pages': total_pages,
                'average_rating': round(avg_rating, 2),
                'total_reviews': total_reviews,
                'avg_pages_per_book': round(total_pages / total_books, 0) if total_books > 0 else 0
            },
            'genres': genre_stats,
            'authors': author_stats,
            'top_themes': top_themes,
            'by_century': year_stats,
            'ratings_distribution': self._get_ratings_distribution(books)
        }
    
    def _get_ratings_distribution(self, books: List[Book]) -> Dict[str, int]:
        """Calcula distribuição de ratings"""
        distribution = {
            '4.5-5.0': 0,
            '4.0-4.4': 0,
            '3.5-3.9': 0,
            '3.0-3.4': 0,
            '2.5-2.9': 0,
            '2.0-2.4': 0,
            'below-2.0': 0
        }
        
        for book in books:
            rating = book.avaliacao_media
            if rating >= 4.5:
                distribution['4.5-5.0'] += 1
            elif rating >= 4.0:
                distribution['4.0-4.4'] += 1
            elif rating >= 3.5:
                distribution['3.5-3.9'] += 1
            elif rating >= 3.0:
                distribution['3.0-3.4'] += 1
            elif rating >= 2.5:
                distribution['2.5-2.9'] += 1
            elif rating >= 2.0:
                distribution['2.0-2.4'] += 1
            else:
                distribution['below-2.0'] += 1
        
        return distribution
    
    def export_data(self, format: str = 'json') -> str:
        """Exporta dados do sistema"""
        books = self.db.get_all_books()
        analytics = self.get_analytics_data()
        
        export_data = {
            'books': [book.to_dict() for book in books],
            'analytics': analytics,
            'export_timestamp': datetime.now().isoformat()
        }
        
        if format == 'json':
            return json.dumps(export_data, indent=2, ensure_ascii=False)
        else:
            raise ValueError(f"Formato não suportado: {format}")