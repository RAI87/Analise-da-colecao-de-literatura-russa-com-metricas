# app_simples.py - Sistema de Recomendação SEM dependências externas
import math

# Base de dados de livros russos
livros = [{
    'titulo': 'Crime e Castigo',
    'autor': 'Dostoiévski',
    'genero': 'psicológico',
    'temas': ['crime', 'culpa', 'redenção']
}, {
    'titulo': 'Guerra e Paz',
    'autor': 'Tolstói',
    'genero': 'épico',
    'temas': ['guerra', 'amor', 'história']
}, {
    'titulo': 'Anna Kariênina',
    'autor': 'Tolstói',
    'genero': 'romance',
    'temas': ['amor', 'traição', 'sociedade']
}, {
    'titulo': 'Os Irmãos Karamázov',
    'autor': 'Dostoiévski',
    'genero': 'filosófico',
    'temas': ['fé', 'liberdade', 'moral']
}, {
    'titulo': 'O Idiota',
    'autor': 'Dostoiévski',
    'genero': 'psicológico',
    'temas': ['inocência', 'sociedade', 'bondade']
}]


def calcular_similaridade(livro1, livro2):
    """Calcula similaridade entre dois livros"""
    score = 0

    # Mesmo autor = +3 pontos
    if livro1['autor'] == livro2['autor']:
        score += 3

    # Mesmo gênero = +2 pontos
    if livro1['genero'] == livro2['genero']:
        score += 2

    # Temas em comum = +1 ponto por tema
    temas_comuns = set(livro1['temas']).intersection(livro2['temas'])
    score += len(temas_comuns)

    return score


def recomendar_livros(livro_gostei):
    """Recomenda livros similares"""
    # Encontrar o livro
    livro_alvo = None
    for livro in livros:
        if livro_gostei.lower() in livro['titulo'].lower():
            livro_alvo = livro
            break

    if not livro_alvo:
        return None

    # Calcular similaridades
    recomendacoes = []
    for livro in livros:
        if livro['titulo'] != livro_alvo['titulo']:
            similaridade = calcular_similaridade(livro_alvo, livro)
            recomendacoes.append((livro, similaridade))

    # Ordenar do mais similar para o menos
    recomendacoes.sort(key=lambda x: x[1], reverse=True)
    return recomendacoes


# Interface do programa
print("SISTEMA DE RECOMENDAÇÃO DE LITERATURA RUSSA")
print("=" * 55)
print("Livros disponíveis:")
for i, livro in enumerate(livros, 1):
    print(f"{i}. {livro['titulo']} - {livro['autor']}")

while True:
    print("\n" + "=" * 55)
    escolha = input("Digite o nome de um livro que você gostou (ou 'sair'): ")

    if escolha.lower() == 'sair':
        print("Até logo!")
        break

    resultados = recomendar_livros(escolha)

    if not resultados:
        print(
            "Livro não encontrado. Tente: Crime e Castigo, Guerra e Paz, etc.")
        continue

    print(f"\n Quem gostou de '{escolha}' também pode gostar:\n")
    for livro, score in resultados[:3]:  # Top 3 recomendações
        print(f"  {livro['titulo']} - {livro['autor']}")
        print(f"   Gênero: {livro['genero']}")
        print(f"   Temas: {', '.join(livro['temas'])}")
        print(f"   Similaridade: {score}/10 pontos")
        print()

print("\n✨ Baseado nos algoritmos de similaridade literária")
